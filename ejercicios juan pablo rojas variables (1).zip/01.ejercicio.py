#Programa que permita multiplicar 3 números.

numero1 = int(input("Ingrese el primer numero: "))
numero2 = int(input("Ingrese el segundo numero: "))
numero3 = int(input("Ingrese el tercer numero: "))

resultado = numero1 * numero2 * numero3

print(f"El resultado de la multiplicación es: {resultado}")