#Programa para calcular el área de un cuadrado, la longitud de un lado la ingresa el usuario.

lado_cuadrado = int(input("Ingrese el valor del lado del cuadrado: "))

area = lado_cuadrado ** 2

print(f"el area del cuadrado es: {area}")