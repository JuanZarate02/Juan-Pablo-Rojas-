#Programa para calcular el 20% de cualquier número de entrada.

num = int(input("ingrese un numero: "))

resultado = num * 0.20

print((f"el 20% del numero {num} es: {resultado}"))