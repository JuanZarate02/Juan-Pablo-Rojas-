#Solicitar al usuario un número y calcular cuál es el cuadrado del número (2^2=4).

numero1 = int(input("ingrese un numero: "))

resultado = numero1 ** 2

print(f"el cuadrado del número {numero1} es: {resultado}")