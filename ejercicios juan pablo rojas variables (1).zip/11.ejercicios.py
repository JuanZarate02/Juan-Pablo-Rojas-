#Programa que solicite un número al usuario y permita calcular la raíz cuadrada del mismo (sin usar función).

num = int(input("ingrese un numero: "))

resultado = num ** 0.5

print(f"el cuadrado del número {num} es: {resultado}")