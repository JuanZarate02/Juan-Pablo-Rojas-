#Solicitar tiempo en segundos y transformar a horas y minutos.

t = int(input("Ingrese el tiempo en segundos: "))

minu = t / 60
horas = t / 3600

print(f"El tiempo en minutos es: {minu}")
print(f"El tiempo en minutos es: {horas}")
