#Programa que permita calcular el 30%, el 60% y el 90% de cualquier número.

num = int(input("ingrese un numero: "))

resultado30 = num * 0.30
resultado60 = num * 0.60
resultado90 = num * 0.90

print((f"el 30% del numero {num} es: {resultado30}"))
print((f"el 60% del numero {num} es: {resultado60}"))
print((f"el 90% del numero {num} es: {resultado90}"))
